package com.lunar.rockets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RocketsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RocketsApplication.class, args);
	}

}
